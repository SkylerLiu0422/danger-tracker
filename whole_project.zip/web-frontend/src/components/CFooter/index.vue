<template>
  <div>©2021 ST 6801 - Group 1</div>
</template>

<script>
export default {
  name: "CFooter"
}
</script>

<style scoped>

</style>