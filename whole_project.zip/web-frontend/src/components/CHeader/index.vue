<template>
  <div style="font-size: 24px">Danger Tracker</div>
</template>

<script>
export default {
  name: "CHeader"
}
</script>

<style scoped>

</style>