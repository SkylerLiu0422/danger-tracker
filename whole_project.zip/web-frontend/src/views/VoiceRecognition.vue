<template>

</template>

<script>
export default {
  name: "VoiceRecognition"
}
</script>

<style scoped>

</style>