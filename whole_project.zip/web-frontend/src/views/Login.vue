<template>
  <n-layout position="absolute" style="top: 64px; bottom: 64px;">
  </n-layout>
</template>

<script>
export default {
  name: "Login.vue"
}
</script>

<style scoped>

</style>